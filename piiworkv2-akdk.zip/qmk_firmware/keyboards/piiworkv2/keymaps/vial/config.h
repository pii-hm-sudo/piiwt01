#pragma once

#define VIAL_KEYBOARD_UID {0x6d, 0x1c, 0x2d, 0xa4, 0x66, 0x40, 0x2a, 0xb3}
#define VIAL_TAP_DANCE_ENTRIES 8
#define VIAL_COMBO_ENTRIES 8
#define PICO_FLASH_SIZE_BYTES (1 * 1024 * 1024)